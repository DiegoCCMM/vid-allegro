Autores: Patricia Briones Yus y Diego Caballé Casanova
Horas invertidas por Patricia: 10 horas
Horas invertidas por Diego: 12 horas

Bibliografía:
StackOverflow
Apuntes Moodle